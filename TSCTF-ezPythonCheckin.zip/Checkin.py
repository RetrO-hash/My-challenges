import json
import subprocess
import threading
import socket
import base64
import os
import random


def handle_connection(s, addr):
    s.send("Hello from {}\n".format(addr).encode())
    s.send("Please send Base64encoding String\n".encode())
    s.send("> ".encode())
    data = b''
    data=s.recv(2048)
    if len(data)>1600:
        s.send("Too long\n".encode())
        s.send("".encode())
        s.close()
        return
    else:
        try:
            decode_data=base64.b64decode(data).decode()
            if "nosec" in decode_data:
                s.send("Not Safe\n".encode())
                s.send("".encode())
                s.close()
                return
            # s.send("OK\n".encode())
            temp_filename="./upload_temp/{}.py".format(random.randint(1,999999))
            open(temp_filename,"w").write(decode_data)
            temp_result=subprocess.run(["bandit","-r",temp_filename,"-f","json"],capture_output=True).stdout.decode()

            if len(json.loads(temp_result)['results'])==0:
                print("[+] OK\n")
                subprocess.run(["python3",temp_filename],timeout=60)
                s.send("[+] Over\n".encode())

            else:
                s.send("Not Safe\n".encode())
                s.send("".encode())
                s.close()
            os.remove(temp_filename)
            s.close()
        except:
            s.send("FAILED!\n".encode())
            s.send("".encode())
            s.close()
            return

def main():
    try:
        os.mkdir('./upload_temp')
    except:
        pass
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('0.0.0.0', 1337))
        s.listen(256)
        while True:
            conn, addr = s.accept()
            print(f"Connection from: {addr}")
            th = threading.Thread(
                target=handle_connection,
                args=(conn, addr),
                daemon=True
            )
            th.start()
if __name__ == "__main__":
    main()